<script setup lang="ts">
import { RouterLink } from "vue-router";
</script>

<template>
  <div class="logo">
    <RouterLink to="/" class="d-flex">
      <img src="@/assets/images/logos/logo-base-white.svg" class="d-block" />
    </RouterLink>
  </div>
</template>
