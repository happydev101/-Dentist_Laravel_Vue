<script setup lang="ts">
import { ref } from "vue";
import ProductCarouselCycle from "./ProductCarouselCycle.vue";

const alert = ref(true);
</script>

<template>
<v-card elevation="1">
  
<ProductCarouselCycle></ProductCarouselCycle>

    <v-card-subtitle class="pt-4"> Number 10 </v-card-subtitle>

    <v-card-text>
      <div>歯科技工士として当システムをご利用いただいている方々へのお知らせを掲載します。</div>
      <div>Whitsunday Island, Whitsunday Islands</div>
    </v-card-text>


</v-card>
 
</template>
