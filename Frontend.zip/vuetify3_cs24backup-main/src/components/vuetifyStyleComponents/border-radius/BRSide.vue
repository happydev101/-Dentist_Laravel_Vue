<script setup lang="ts"></script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Rounding by side -->
  <!-- ----------------------------------------------------------------------------- -->
  <div class="d-flex justify-space-around">
    <div class="pa-4 bg-secondary rounded-t-xl">.rounded-t-xl</div>

    <div class="pa-4 bg-secondary rounded-b-xl">.rounded-b-xl</div>

    <div class="pa-4 bg-secondary rounded-s-xl">.rounded-s-xl</div>

    <div class="pa-4 bg-secondary rounded-e-xl">.rounded-e-xl</div>
  </div>
</template>
