<script setup lang="ts"></script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Rounding by corner -->
  <!-- ----------------------------------------------------------------------------- -->
  <div class="d-flex justify-space-around">
    <div class="pa-4 bg-secondary rounded-ts-xl">.rounded-ts-xl</div>

    <div class="pa-4 bg-secondary rounded-te-xl">.rounded-te-xl</div>

    <div class="pa-4 bg-secondary rounded-be-xl">.rounded-be-xl</div>

    <div class="pa-4 bg-secondary rounded-bs-xl">.rounded-bs-xl</div>
  </div>
</template>
