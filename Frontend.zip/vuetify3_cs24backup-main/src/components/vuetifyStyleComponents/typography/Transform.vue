<script setup lang="ts">
</script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- transform -->
  <!-- ----------------------------------------------------------------------------- -->
  <p class="text-lowercase">
      Lowercased text.
    </p>
    <p class="text-uppercase">
      Uppercased text.
    </p>
    <p class="text-capitalize">
      capitalized text.
    </p>
</template>
