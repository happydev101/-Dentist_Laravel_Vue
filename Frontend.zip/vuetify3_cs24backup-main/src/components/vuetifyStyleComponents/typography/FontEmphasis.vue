<script setup lang="ts">
</script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Font emphasis -->
  <!-- ----------------------------------------------------------------------------- -->
  <p class="font-weight-black">Black text.</p>
  <p class="font-weight-bold">Bold text.</p>
  <p class="font-weight-medium">Medium weight text.</p>
  <p class="font-weight-regular">Normal weight text.</p>
  <p class="font-weight-light">Light weight text.</p>
  <p class="font-weight-thin">Thin weight text.</p>
  <p class="font-italic">Italic text.</p>
</template>
