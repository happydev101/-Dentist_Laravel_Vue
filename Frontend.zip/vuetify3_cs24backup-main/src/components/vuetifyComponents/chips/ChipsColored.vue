<script setup lang="ts">
</script>


<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Colored -->
  <!-- ----------------------------------------------------------------------------- -->
  <div class="d-flex flex-wrap gap-2">
    <v-chip> Default </v-chip>

    <v-chip color="primary"> Primary </v-chip>

    <v-chip color="secondary"> Secondary </v-chip>

    <v-chip color="error" text-color="white"> Error </v-chip>

    <v-chip color="warning" text-color="white"> Warning </v-chip>
    <v-chip color="success" text-color="white"> Success </v-chip>
  </div>
</template>
