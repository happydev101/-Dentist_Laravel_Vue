<script setup lang="ts">
</script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Outlined -->
  <!-- ----------------------------------------------------------------------------- -->
  <div class="d-flex flex-wrap gap-2">
    <v-chip variant="outlined"> Default </v-chip>
    <v-chip variant="outlined" color="primary"> Primary </v-chip>
    <v-chip variant="outlined" color="secondary"> Secondary </v-chip>
    <v-chip variant="outlined" color="error"> Error </v-chip>
    <v-chip variant="outlined" color="warning"> Warning </v-chip>
    <v-chip variant="outlined" color="success"> Success </v-chip>
  </div>
</template>
