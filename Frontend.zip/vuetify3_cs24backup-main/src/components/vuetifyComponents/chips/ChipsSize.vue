<script setup lang="ts">
</script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Size -->
  <!-- ----------------------------------------------------------------------------- -->
  <div class="d-flex flex-wrap gap-2">
    <v-chip size="x-small" color="primary"> x-small </v-chip>
    <v-chip size="small" color="secondary"> Small </v-chip>
    <v-chip color="error"> Normal </v-chip>
    <v-chip size="large" color="warning"> Large </v-chip>
    <v-chip size="x-large" color="success"> x-Large </v-chip>
  </div>
</template>
