<script setup lang="ts">
</script>


<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Drag -->
  <!-- ----------------------------------------------------------------------------- -->
  <div class="text-center">
    <v-chip color="secondary" draggable>
      Default
    </v-chip>
  </div>
</template>
