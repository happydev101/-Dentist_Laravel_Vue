<script setup lang="ts">
</script>


<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Label -->
  <!-- ----------------------------------------------------------------------------- -->
  <div class="d-flex flex-wrap gap-2">
    <v-chip label> Label </v-chip>

    <v-chip color="primary" label> Primary </v-chip>
    <v-chip color="secondary" label> Secondary </v-chip>
    <v-chip color="error" label> Error </v-chip>
    <v-chip color="warning" label> Warning </v-chip>
    <v-chip color="success" label> Success </v-chip>

   
  </div>
</template>
