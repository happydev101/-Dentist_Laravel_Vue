<script setup lang="ts">
</script>


<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- No Ripple -->
  <!-- ----------------------------------------------------------------------------- -->
  <div class="text-center">
    <v-chip :ripple="false" color="primary" link> No Ripple </v-chip>
  </div>
</template>
