<script setup lang="ts">
</script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Center Active -->
  <!-- ----------------------------------------------------------------------------- -->
  <div>
    <p class="text-subtitle-1 text-grey-darken-1">
      The center-active prop will make the active tab always centered
    </p>
    <div class="mt-6">
      <v-card >
        <v-tabs background-color="secondary" class="d-flex align-center" center-active>
          <v-tab>One</v-tab>
          <v-tab>Two</v-tab>
          <v-tab>Three</v-tab>
          <v-tab>Four</v-tab>
          <v-tab>Five</v-tab>
          <v-tab>Six</v-tab>
          <v-tab>Seven</v-tab>
          <v-tab>Eight</v-tab>
          <v-tab>Nine</v-tab>
          <v-tab>Ten</v-tab>
          <v-tab>Eleven</v-tab>
          <v-tab>Twelve</v-tab>
          <v-tab>Thirteen</v-tab>
          <v-tab>Fourteen</v-tab>
          <v-tab>Fifteen</v-tab>
          <v-tab>Sixteen</v-tab>
          <v-tab>Seventeen</v-tab>
          <v-tab>Eighteen</v-tab>
          <v-tab>Nineteen</v-tab>
          <v-tab>Twenty</v-tab>
        </v-tabs>
      </v-card>
    </div>
  </div>
</template>

