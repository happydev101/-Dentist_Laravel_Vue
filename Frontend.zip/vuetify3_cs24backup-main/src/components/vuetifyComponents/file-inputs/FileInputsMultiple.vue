<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- FileInputs Multiple -->
  <!-- ----------------------------------------------------------------------------- -->
  <div>
    <p class="text-subtitle-1 text-grey-darken-1">
      The <code>v-file-input</code> can contain multiple files at the same time
      when using the multiple prop.
    </p>
    <div class="mt-4">
      <v-file-input multiple label="File input"></v-file-input>
    </div>
  </div>
</template>

<script setup lang="ts"></script>
