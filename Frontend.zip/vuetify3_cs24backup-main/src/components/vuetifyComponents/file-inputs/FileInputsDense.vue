<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- FileInputs Dense -->
  <!-- ----------------------------------------------------------------------------- -->
  <div>
    <p class="text-subtitle-1 text-grey-darken-1">
      You can reduces the file input height with <code>dense</code> prop.
    </p>
    <div class="mt-4">
      <v-file-input label="File input" outlined dense></v-file-input>
    </div>
  </div>
</template>

<script setup lang="ts"></script>
