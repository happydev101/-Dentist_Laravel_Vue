<script setup lang="ts"></script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Outlined -->
  <!-- ----------------------------------------------------------------------------- -->
  <v-card class="mx-auto" variant="outlined">
    <v-card-item>
      <div>
        <div class="text-overline mb-1">OVERLINE</div>
        <div class="text-h6 mb-1">Headline</div>
        <div class="text-caption">
          Greyhound divisely hello coldly fonwderfully
        </div>
      </div>
    </v-card-item>
    <v-card-actions>
      <v-btn variant="outlined"> Button </v-btn>
    </v-card-actions>
  </v-card>
</template>
