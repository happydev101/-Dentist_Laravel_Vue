<script setup lang="ts"></script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Markup -->
  <!-- ----------------------------------------------------------------------------- -->
  
  <v-card>
    <v-card-header>
      <v-card-header-text>
        <v-card-title>This is a title</v-card-title>
        <v-card-subtitle>This is a subtitle</v-card-subtitle>
      </v-card-header-text>
    </v-card-header>

    <v-card-text> This is content </v-card-text>
  </v-card>
</template>
