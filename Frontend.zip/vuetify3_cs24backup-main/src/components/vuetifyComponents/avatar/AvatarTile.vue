<script setup lang="ts"></script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Tile -->
  <!-- ----------------------------------------------------------------------------- -->
  <div>
    <p class="text-subtitle-1 text-grey-darken-1">
      The <code>tile</code> prop removes the border radius from v-avatar leaving
      you with a simple square avatar.
    </p>
    <div class="mt-6 text-center">
      <v-avatar rounded="0" color="primary">
        <v-icon icon="mdi-alarm"></v-icon>
      </v-avatar>
    </div>
  </div>
</template>

