<script setup lang="ts"></script>
<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- TextareasBrowserAutocomplete -->
  <!-- ----------------------------------------------------------------------------- -->
  <div>
    <p class="text-subtitle-1 text-grey-darken-1">
      The <code>autocomplete</code> prop gives you the option to enable the
      browser to predict user inpu
    </p>
    <div class="mt-4">
      <v-textarea autocomplete="email" label="Email"></v-textarea>
    </div>
  </div>
</template>
