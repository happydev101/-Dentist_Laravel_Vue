<script setup lang="ts">
</script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Custom Icon -->
  <!-- ----------------------------------------------------------------------------- -->
  <v-expansion-panels class="mb-6">
    <v-expansion-panel v-for="i in 3" :key="i">
      <v-expansion-panel-title expand-icon="mdi-menu-down">
        Item
      </v-expansion-panel-title>
      <v-expansion-panel-text
        >Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
        veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
        commodo consequat.</v-expansion-panel-text
      >
    </v-expansion-panel>
  </v-expansion-panels>

  <v-expansion-panels>
    <v-expansion-panel>
      <v-expansion-panel-title expand-icon="mdi-plus" collapse-icon="mdi-minus">
        Item
      </v-expansion-panel-title>
      <v-expansion-panel-text>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
        veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
        commodo consequat.
      </v-expansion-panel-text>
    </v-expansion-panel>

    <v-expansion-panel>
      <v-expansion-panel-title>
        Item
        <template v-slot:actions="{ expanded }">
          <v-icon
            :color="!expanded ? 'teal' : ''"
            :icon="expanded ? 'mdi-pencil' : 'mdi-check'"
          ></v-icon>
        </template>
      </v-expansion-panel-title>
      <v-expansion-panel-text>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
        veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
        commodo consequat.
      </v-expansion-panel-text>
    </v-expansion-panel>

    <v-expansion-panel>
      <v-expansion-panel-title disable-icon-rotate>
        Item
        <template v-slot:actions>
          <v-icon color="error" icon="mdi-alert-circle"> </v-icon>
        </template>
      </v-expansion-panel-title>
      <v-expansion-panel-text>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
        veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
        commodo consequat.
      </v-expansion-panel-text>
    </v-expansion-panel>
  </v-expansion-panels>
</template>
