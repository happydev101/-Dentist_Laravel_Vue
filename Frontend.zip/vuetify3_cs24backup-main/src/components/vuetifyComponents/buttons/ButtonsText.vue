<script setup lang="ts"></script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Default -->
  <!-- ----------------------------------------------------------------------------- -->
  <div class="d-flex flex-wrap gap-2">
      
      <div>
        <v-btn variant="text" color="primary">Primary</v-btn>
      </div>
      <div>
        <v-btn variant="text" color="secondary">Secondary</v-btn>
      </div>
      <div>
        <v-btn variant="text" color="error">Error</v-btn>
      </div>
      <div>
        <v-btn variant="text" color="warning">Warning</v-btn>
      </div>
      <div>
        <v-btn variant="text" color="success">Success</v-btn>
      </div>
      <div>
        <v-btn variant="text" disabled>Disabled</v-btn>
      </div>
      <div>
        <v-btn variant="text">Normal</v-btn>
      </div>
  </div>
</template>
