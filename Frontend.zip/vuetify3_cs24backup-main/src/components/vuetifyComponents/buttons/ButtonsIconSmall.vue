<script setup lang="ts"></script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Icons small -->
  <!-- ----------------------------------------------------------------------------- -->
  <div class="d-flex flex-wrap gap-2">
      
      <v-btn size="small"
        icon="mdi-heart"
        color="primary"
      ></v-btn>

      <v-btn size="small"
        icon="mdi-star"
        color="secondary"
      ></v-btn>

      <v-btn size="small"
        icon="mdi-cached"
        color="warning"
      ></v-btn>

      <v-btn size="small"
        icon="mdi-thumb-up"
        color="success"
      ></v-btn>
  </div>
</template>
