<script setup lang="ts"></script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Icons large -->
  <!-- ----------------------------------------------------------------------------- -->
  <div class="d-flex flex-wrap gap-2">
      
      <v-btn size="large"
        icon="mdi-heart"
        color="primary"
      ></v-btn>

      <v-btn size="large"
        icon="mdi-star"
        color="secondary"
      ></v-btn>

      <v-btn size="large"
        icon="mdi-cached"
        color="warning"
      ></v-btn>

      <v-btn size="large"
        icon="mdi-thumb-up"
        color="success"
      ></v-btn>
  </div>
</template>
