<script setup lang="ts">
</script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Column Wrapping  -->
  <!-- ----------------------------------------------------------------------------- -->
  <v-container class="bg-grey-lighten-5">
    <v-row no-gutters>
      <v-col cols="9">
        <v-sheet class="pa-2 ma-2">
          .v-col-9
        </v-sheet>
      </v-col>
      <v-col cols="4">
        <v-sheet class="pa-2 ma-2">
          .v-col-4
        </v-sheet>
      </v-col>
      <v-col cols="6">
        <v-sheet class="pa-2 ma-2">
          .v-col-6
        </v-sheet>
      </v-col>
    </v-row>
  </v-container>
</template>
