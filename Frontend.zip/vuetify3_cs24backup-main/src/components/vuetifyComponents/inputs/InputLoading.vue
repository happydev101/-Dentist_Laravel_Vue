<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Loading -->
  <!-- ----------------------------------------------------------------------------- -->
  <div>
    <p class="text-subtitle-1 text-grey-darken-1">
      <code>v-input</code> has <code>loading</code> state which can be used,
      e.g. for data loading indication. Note: <code>v-text-field</code> is used
      just for example.
    </p>
    <div class="mt-4">
      <v-text-field color="success" loading disabled></v-text-field>
    </div>
  </div>
</template>

<script setup lang="ts"></script>
