<script setup lang="ts"></script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- SlidersInverseLabel -->
  <!-- ----------------------------------------------------------------------------- -->
  <div>
    <p class="text-subtitle-1 text-grey-darken-1">
      <code>v-slider</code> with <code>inverse-label</code> property displays
      label at the end of it.
    </p>
    <div class="mt-4">
      <v-slider inverse-label label="Inverse label" value="30"></v-slider>
    </div>
  </div>
</template>