<script setup lang="ts">
</script>

<template>
    <!-- ----------------------------------------------------------------------------- -->
    <!-- TextfieldValidation -->
    <!-- ----------------------------------------------------------------------------- -->
    <div>
        <p class="text-subtitle-1 text-grey-darken-1">
           Vuetify includes simple validation through the <code>rules</code> prop. The prop accepts an array of callbacks. While validating rules, the current v-model value will be passed to the callback. This callback should return either true or a String, the error message.
        </p>
        <div class="mt-4">
        </div>
    </div>
</template>
